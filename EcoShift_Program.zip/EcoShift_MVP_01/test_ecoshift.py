"""Проверка ограничений и работы оптимизатора: python -m unittest -v."""
import unittest
from collections import defaultdict
from pathlib import Path

from ecoshift import (Operation, baseline_schedule, load_problem,
                      optimize_schedule, verify_schedule)

ROOT = Path(__file__).resolve().parent


class EcoShiftTests(unittest.TestCase):
    def test_demo_is_feasible_and_no_more_expensive(self):
        config, machines, _names, operations, rates, down, horizon = load_problem()
        normal = baseline_schedule(config, machines, operations, rates, down, horizon)
        improved, status = optimize_schedule(config, machines, operations, rates, down, horizon)
        a = verify_schedule(normal, config, machines, operations, rates, down, horizon)
        b = verify_schedule(improved, config, machines, operations, rates, down, horizon)
        self.assertLessEqual(b["cost_rub"], a["cost_rub"])
        self.assertAlmostEqual(b["energy_kwh"], a["energy_kwh"])
        self.assertEqual(status, "Доказанный оптимум")
        self.assertEqual(len(improved), 11)

    def test_downtime_restricts_station(self):
        cfg, mach, _names, ops, rates, down, horizon = load_problem(
            str(ROOT / "data/downtime_example.csv"))
        result, _ = optimize_schedule(cfg, mach, ops, rates, down, horizon)
        verify_schedule(result, cfg, mach, ops, rates, down, horizon)
        for oid, start in result.items():
            op = ops[oid]
            if op.machine_id == "M2":
                self.assertTrue(set(range(start, start + op.duration)).isdisjoint(down["M2"]))

    def test_small_case_matches_known_optimum(self):
        cfg = {"slot_minutes": 30, "power_cap_kw": 5,
               "day_start_hour": 8, "day_end_hour": 10,
               "solver_time_limit_seconds": 20}
        machines = {"M1": 3, "M2": 3}
        operations = {
            "A": Operation("A", "A", "M1", 1, 0, 4, None),
            "B": Operation("B", "B", "M2", 1, 0, 4, None),
        }
        rates = [10, 10, 2, 2]
        best, status = optimize_schedule(cfg, machines, operations, rates, defaultdict(set), 4)
        metrics = verify_schedule(best, cfg, machines, operations, rates, defaultdict(set), 4)
        self.assertEqual(status, "Доказанный оптимум")
        self.assertEqual(metrics["cost_rub"], 6.0)
        self.assertEqual(metrics["peak_kw"], 3)
        self.assertEqual(set(best.values()), {2, 3})

    def test_validator_rejects_overlap(self):
        cfg = {"slot_minutes": 30, "power_cap_kw": 10}
        ops = {"A": Operation("A", "A", "M", 1, 0, 2, None),
               "B": Operation("B", "B", "M", 1, 0, 2, None)}
        with self.assertRaises(AssertionError):
            verify_schedule({"A": 0, "B": 0}, cfg, {"M": 5}, ops, [3, 3], defaultdict(set), 2)


if __name__ == "__main__":
    unittest.main()
