#!/usr/bin/env python3
"""EcoShift, этап 1: планировщик операций по тарифам (демо-данные).

Модель: назначенная машина на каждую неперерываемую операцию; 30-минутные
интервалы; тариф, зависящий от времени; предшествование, дедлайны,
ограничения мощности и простои.

Оптимизация: точная смешанно-целочисленная модель (SciPy/HiGHS).
Если тайм-лимит достигнут, статус результата сообщается явно.
"""
from __future__ import annotations

import argparse
import json
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix

ROOT = Path(__file__).resolve().parent


@dataclass(frozen=True)
class Operation:
    operation_id: str
    job_id: str
    machine_id: str
    duration: int
    release: int
    deadline: int
    predecessor: str | None


def clock(slot: int, start_hour: int, slot_minutes: int) -> str:
    total = 60 * start_hour + slot * slot_minutes
    return f"{total // 60:02d}:{total % 60:02d}"


def load_problem(downtime_filename: str | None = None):
    with (ROOT / "config.json").open(encoding="utf-8") as handle:
        config = json.load(handle)
    step = config["slot_minutes"]
    assert step > 0 and 60 % step == 0
    horizon = (config["day_end_hour"] - config["day_start_hour"]) * 60 // step
    shift_end_slot = (config.get("latest_completion_hour", config["day_end_hour"])
                      - config["day_start_hour"]) * 60 // step
    if not (0 < shift_end_slot <= horizon):
        raise ValueError("latest_completion_hour должен быть в пределах горизонта")

    machines_df = pd.read_csv(ROOT / "data/machines.csv")
    operations_df = pd.read_csv(ROOT / "data/operations.csv", keep_default_na=False)
    tariffs_df = pd.read_csv(ROOT / "data/tariffs.csv")
    machines = dict(zip(machines_df.machine_id, machines_df.power_kw.astype(int)))
    machine_names = dict(zip(machines_df.machine_id, machines_df.machine_name))
    assert all(p > 0 for p in machines.values())
    assert len(machines) == len(machines_df)

    operations = {}
    for row in operations_df.itertuples(index=False):
        op = Operation(
            operation_id=str(row.operation_id), job_id=str(row.job_id),
            machine_id=str(row.machine_id), duration=int(row.duration_slots),
            release=int(row.release_slot),
            # Конец смены — глобальное ограничение поверх дедлайна заказа.
            deadline=min(int(row.deadline_slot), shift_end_slot),
            predecessor=str(row.predecessor) or None,
        )
        if op.operation_id in operations:
            raise ValueError(f"Повтор ID операции: {op.operation_id}")
        if op.machine_id not in machines:
            raise ValueError(f"Неизвестный станок: {op.machine_id}")
        if not (0 <= op.release < op.deadline <= horizon) or op.duration <= 0:
            raise ValueError(f"Некорректные времена операции {op.operation_id}")
        operations[op.operation_id] = op
    for op in operations.values():
        if op.predecessor and op.predecessor not in operations:
            raise ValueError(f"Неизвестная предшествующая операция: {op.predecessor}")
    rates = [None] * horizon
    for row in tariffs_df.itertuples(index=False):
        start = (int(row.start_hour) - config["day_start_hour"]) * 60 // step
        end = (int(row.end_hour) - config["day_start_hour"]) * 60 // step
        if not (0 <= start < end <= horizon) or int(row.price_rub_kwh) <= 0:
            raise ValueError("Тариф выходит за горизонт или имеет некорректную цену")
        for t in range(start, end):
            if rates[t] is not None:
                raise ValueError(f"Пересечение тарифных периодов в слоте {t}")
            rates[t] = int(row.price_rub_kwh)
    if any(rate is None for rate in rates):
        raise ValueError("Тарифы должны полностью покрывать рабочий горизонт")

    downtime = defaultdict(set)
    if downtime_filename:
        df = pd.read_csv(downtime_filename)
        for row in df.itertuples(index=False):
            if row.machine_id not in machines or not (0 <= row.start_slot < row.end_slot <= horizon):
                raise ValueError("Некорректный простой оборудования")
            downtime[row.machine_id].update(range(int(row.start_slot), int(row.end_slot)))
    return config, machines, machine_names, operations, rates, downtime, horizon


def allowed_starts(op: Operation, downtime: dict):
    blocked = downtime.get(op.machine_id, set())
    return [s for s in range(op.release, op.deadline - op.duration + 1)
            if all(t not in blocked for t in range(s, s + op.duration))]


def verify_schedule(starts, config, machines, operations, rates, downtime, horizon):
    """Отдельная от оптимизатора проверка всех технических ограничений."""
    if set(starts) != set(operations):
        raise AssertionError("В расписании есть пропущенные/лишние операции")
    machine_use = defaultdict(set)
    power_profile = [0] * horizon
    for oid, s in starts.items():
        op = operations[oid]
        if s not in allowed_starts(op, downtime):
            raise AssertionError(f"Нарушен допустимый интервал для {oid}")
        for t in range(s, s + op.duration):
            if t in machine_use[op.machine_id]:
                raise AssertionError(f"Пересечение на {op.machine_id}, слот {t}")
            machine_use[op.machine_id].add(t)
            power_profile[t] += machines[op.machine_id]
    for oid, op in operations.items():
        if op.predecessor:
            pred = operations[op.predecessor]
            if starts[oid] < starts[pred.operation_id] + pred.duration:
                raise AssertionError(f"Нарушена последовательность: {oid}")
    if max(power_profile) > config["power_cap_kw"]:
        raise AssertionError("Превышена установленная мощность")
    hours = config["slot_minutes"] / 60
    energy_kwh = sum(power_profile) * hours
    cost_rub = sum(power_profile[t] * rates[t] * hours for t in range(horizon))
    return {"cost_rub": cost_rub, "energy_kwh": energy_kwh,
            "peak_kw": max(power_profile), "power_profile": power_profile}


def baseline_schedule(config, machines, operations, rates, downtime, horizon):
    """Жадный эталон: ближайший допустимый слот, приоритет ранних дедлайнов."""
    starts = {}
    remaining = set(operations)
    machine_usage = defaultdict(set)
    power = [0] * horizon
    while remaining:
        ready = [operations[oid] for oid in remaining
                 if operations[oid].predecessor is None or operations[oid].predecessor in starts]
        if not ready:
            raise ValueError("В зависимостях операций обнаружен цикл")
        op = min(ready, key=lambda x: (x.deadline, x.release, x.operation_id))
        earliest = op.release
        if op.predecessor:
            pred = operations[op.predecessor]
            earliest = max(earliest, starts[pred.operation_id] + pred.duration)
        feasible = False
        for s in allowed_starts(op, downtime):
            if s < earliest:
                continue
            if any(t in machine_usage[op.machine_id] for t in range(s, s + op.duration)):
                continue
            if any(power[t] + machines[op.machine_id] > config["power_cap_kw"]
                   for t in range(s, s + op.duration)):
                continue
            starts[op.operation_id] = s
            for t in range(s, s + op.duration):
                machine_usage[op.machine_id].add(t)
                power[t] += machines[op.machine_id]
            feasible = True
            break
        if not feasible:
            raise ValueError(f"Базовое жадное расписание не найдено: {op.operation_id}")
        remaining.remove(op.operation_id)
    verify_schedule(starts, config, machines, operations, rates, downtime, horizon)
    return starts


def optimize_schedule(config, machines, operations, rates, downtime, horizon):
    """MILP: бинарная переменная для каждого допустимого начала операции."""
    options = []
    by_op = defaultdict(list)
    for oid, op in operations.items():
        candidate_starts = allowed_starts(op, downtime)
        if not candidate_starts:
            raise ValueError(f"Нет допустимых начальных моментов для {oid}")
        for s in candidate_starts:
            idx = len(options)
            options.append((oid, s, s + op.duration))
            by_op[oid].append(idx)

    # Сначала минимизируем цену; при одинаковой цене — более ранние начала.
    # Цена дискретизирована в единицах «рубль / slot_hours»;
    # множитель PRIORITY гарантирует, что малый tie-break не испортит цену.
    priority = len(operations) * horizon + 1
    coefficients = []
    for oid, s, e in options:
        op = operations[oid]
        energy_price_scaled = machines[op.machine_id] * sum(rates[s:e])
        coefficients.append(energy_price_scaled * priority + s)
    c = np.array(coefficients, dtype=float)

    rows, cols, vals, lowers, uppers = [], [], [], [], []
    def constraint(terms, lower=-np.inf, upper=np.inf):
        ridx = len(lowers)
        for j, coefficient in terms:
            rows.append(ridx)
            cols.append(j)
            vals.append(float(coefficient))
        lowers.append(lower)
        uppers.append(upper)

    for oid, indices in by_op.items():
        constraint(((j, 1) for j in indices), 1, 1)
    for machine_id in machines:
        for t in range(horizon):
            constraint(((j, 1) for j, (oid, s, e) in enumerate(options)
                        if operations[oid].machine_id == machine_id and s <= t < e), upper=1)
    for t in range(horizon):
        constraint(((j, machines[operations[oid].machine_id])
                    for j, (oid, s, e) in enumerate(options) if s <= t < e),
                   upper=config["power_cap_kw"])
    for oid, op in operations.items():
        if op.predecessor:
            # start(op) - start(pred) >= duration(pred)
            pred = operations[op.predecessor]
            terms = [(j, -s) for j, (_, s, _) in enumerate(options) if j in by_op[oid]]
            terms += [(j, s) for j, (_, s, _) in enumerate(options) if j in by_op[pred.operation_id]]
            constraint(terms, upper=-pred.duration)

    matrix = coo_matrix((vals, (rows, cols)), shape=(len(lowers), len(options))).tocsr()
    result = milp(
        c=c, integrality=np.ones(len(options)),
        bounds=Bounds(0, 1),
        constraints=LinearConstraint(matrix, np.array(lowers), np.array(uppers)),
        options={"time_limit": float(config.get("solver_time_limit_seconds", 20)),
                 "mip_rel_gap": 0.0},
    )
    if result.x is None:
        raise RuntimeError(f"Оптимизатор не нашёл решение. Статус={result.status}: {result.message}")
    starts = {}
    for j, value in enumerate(result.x):
        if value > 0.5:
            oid, s, _ = options[j]
            starts[oid] = s
    verify_schedule(starts, config, machines, operations, rates, downtime, horizon)
    status = "Доказанный оптимум" if result.status == 0 else "Допустимое решение (не доказан оптимум)"
    return starts, status


def to_dataframe(starts, config, machines, machine_names, operations, rates):
    hours_per_slot = config["slot_minutes"] / 60
    rows = []
    for oid, s in starts.items():
        op = operations[oid]
        e = s + op.duration
        rows.append({
            "Операция": oid, "Заказ": op.job_id, "Станок": machine_names[op.machine_id],
            "Начало": clock(s, config["day_start_hour"], config["slot_minutes"]),
            "Конец": clock(e, config["day_start_hour"], config["slot_minutes"]),
            "Длительность, ч": op.duration * hours_per_slot,
            "Энергия, кВт·ч": machines[op.machine_id] * op.duration * hours_per_slot,
            "Стоимость, руб": machines[op.machine_id] * sum(rates[s:e]) * hours_per_slot,
        })
    return pd.DataFrame(rows).sort_values(["Начало", "Станок", "Операция"])


def make_charts(outdir, config, machine_names, operations, original, optimized,
                base_metrics, opt_metrics, rates, horizon):
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                         "axes.titlesize": 13, "figure.dpi": 135})
    step_hours = config["slot_minutes"] / 60
    start_hour = config["day_start_hour"]
    colors = {"A": "#4C78A8", "B": "#F58518", "C": "#54A24B", "D": "#B279A2"}
    for filename, title, schedule in [
        ("01_gantt_standard.png", "Обычное расписание", original),
        ("02_gantt_ecoshift.png", "EcoShift: оптимизированное расписание", optimized)]:
        fig, ax = plt.subplots(figsize=(11, 4.1))
        mids = list(machine_names)
        for oid, s in schedule.items():
            op = operations[oid]
            y = mids.index(op.machine_id)
            x = start_hour + s * step_hours
            width = op.duration * step_hours
            ax.barh(y, width, left=x, height=0.58,
                    color=colors.get(op.job_id, "#888888"), edgecolor="white", linewidth=1)
            ax.text(x + width / 2, y, oid, ha="center", va="center", color="white", fontsize=9, weight="bold")
        ax.set(yticks=range(len(mids)), yticklabels=[machine_names[m] for m in mids],
               xlim=(start_hour, config["day_end_hour"]), xlabel="Время суток", title=title)
        ax.invert_yaxis()
        ax.grid(axis="x", alpha=.2)
        ax.set_axisbelow(True)
        ax.set_xticks(list(range(start_hour, config["day_end_hour"] + 1, 2)))
        fig.tight_layout()
        fig.savefig(outdir / filename)
        plt.close(fig)

    times = [start_hour + t * step_hours for t in range(horizon)]
    fig, ax = plt.subplots(figsize=(11, 4.6))
    ax.step(times + [config["day_end_hour"]],
            base_metrics["power_profile"] + [base_metrics["power_profile"][-1]],
            where="post", label="Обычное расписание", linewidth=2)
    ax.step(times + [config["day_end_hour"]],
            opt_metrics["power_profile"] + [opt_metrics["power_profile"][-1]],
            where="post", label="EcoShift", linewidth=2)
    ax.axhline(config["power_cap_kw"], color="firebrick", ls="--", lw=1.5,
               label="Ограничение мощности")
    ax.set(xlim=(start_hour, config["day_end_hour"]), xlabel="Время суток",
           ylabel="Потребляемая мощность, кВт", title="Профиль нагрузки участка")
    ax.grid(alpha=.2)
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(outdir / "03_power_profile.png")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 4.7))
    values = [base_metrics["cost_rub"], opt_metrics["cost_rub"]]
    bars = ax.bar(["Обычное", "EcoShift"], values, color=["#7C8DA6", "#38A39A"], width=.55)
    for bar, value in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + max(values) * .02,
                f"{value:,.0f} руб.", ha="center", fontsize=12, weight="bold")
    ax.set_ylim(0, max(values) * 1.2)
    ax.set(ylabel="Стоимость электричества, руб.",
           title="Стоимость выполнения одинакового набора заказов")
    ax.grid(axis="y", alpha=.2)
    ax.set_axisbelow(True)
    fig.tight_layout()
    fig.savefig(outdir / "04_cost_comparison.png")
    plt.close(fig)

    pd.DataFrame({
        "Время": [clock(t, start_hour, config["slot_minutes"]) for t in range(horizon)],
        "Тариф, руб/кВт·ч": rates,
        "Мощность обычная, кВт": base_metrics["power_profile"],
        "Мощность EcoShift, кВт": opt_metrics["power_profile"],
    }).to_csv(outdir / "power_by_slot.csv", index=False, encoding="utf-8-sig")


def run(output_directory: str, downtime_filename: str | None = None):
    config, machines, machine_names, operations, rates, downtime, horizon = load_problem(downtime_filename)
    outdir = Path(output_directory)
    outdir.mkdir(parents=True, exist_ok=True)
    baseline = baseline_schedule(config, machines, operations, rates, downtime, horizon)
    optimum, status = optimize_schedule(config, machines, operations, rates, downtime, horizon)
    base = verify_schedule(baseline, config, machines, operations, rates, downtime, horizon)
    best = verify_schedule(optimum, config, machines, operations, rates, downtime, horizon)
    delta = 100 * (base["cost_rub"] - best["cost_rub"]) / base["cost_rub"]

    to_dataframe(baseline, config, machines, machine_names, operations, rates).to_csv(
        outdir / "schedule_standard.csv", index=False, encoding="utf-8-sig")
    to_dataframe(optimum, config, machines, machine_names, operations, rates).to_csv(
        outdir / "schedule_ecoshift.csv", index=False, encoding="utf-8-sig")
    make_charts(outdir, config, machine_names, operations, baseline, optimum, base, best, rates, horizon)
    makespan_standard = max(baseline[oid] + operations[oid].duration for oid in baseline)
    makespan_ecoshift = max(optimum[oid] + operations[oid].duration for oid in optimum)
    finish_standard = clock(makespan_standard, config["day_start_hour"], config["slot_minutes"])
    finish_ecoshift = clock(makespan_ecoshift, config["day_start_hour"], config["slot_minutes"])
    summary = {
        "scenario": "С простоем станка" if downtime_filename else "Основной",
        "optimization_status": status,
        "operation_count": len(operations),
        "standard_finish": finish_standard,
        "ecoshift_finish": finish_ecoshift,
        "standard_cost_rub": base["cost_rub"], "ecoshift_cost_rub": best["cost_rub"],
        "saving_rub": base["cost_rub"] - best["cost_rub"],
        "saving_percent": delta,
        "standard_energy_kwh": base["energy_kwh"], "ecoshift_energy_kwh": best["energy_kwh"],
        "standard_peak_kw": base["peak_kw"], "ecoshift_peak_kw": best["peak_kw"],
    }
    (outdir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print("EcoShift — этап 1 (демонстрационная модель)")
    print(f"Операций: {len(operations)} | {status}")
    print(f"Обычное расписание: {base['cost_rub']:.2f} руб.")
    print(f"EcoShift:            {best['cost_rub']:.2f} руб.")
    print(f"Разница:             {base['cost_rub'] - best['cost_rub']:.2f} руб. ({delta:.1f}%)")
    print(f"Энергия:             {base['energy_kwh']:.1f} и {best['energy_kwh']:.1f} кВт·ч")
    print(f"Окончание работ:     {finish_standard} и {finish_ecoshift}")
    print(f"Пиковая мощность:    {base['peak_kw']} и {best['peak_kw']} кВт")
    print(f"Результаты: {outdir.resolve()}")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="EcoShift: демонстрация энергозависимого планирования")
    parser.add_argument("--output", default=str(ROOT / "results"), help="Каталог результатов")
    parser.add_argument("--downtime", default=None, help="CSV с простоями оборудования (сценарное моделирование)")
    args = parser.parse_args()
    run(args.output, args.downtime)
